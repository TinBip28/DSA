package week6.ex1;

public interface Entry<K, E> {
    K getKey();
    E getValue();
}

