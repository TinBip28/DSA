package exercise6.p_2_32.entity;

public enum EAnimal {
    TIGER,
    FISH,
    BEAR
}
