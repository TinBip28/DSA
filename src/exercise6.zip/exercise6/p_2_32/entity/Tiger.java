package exercise6.p_2_32.entity;

public class Tiger extends Animal {

    public Tiger(String name, boolean isMale, double power) {
        super(name, isMale, power);
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
