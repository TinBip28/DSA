package week2.card_game;

public interface ISort<Card>{
    void sort(Card[] arr);
}
