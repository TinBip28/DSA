package week2.ex2;

public interface ISort<T>{
    void sort(T[] arr);
}
