package week1.exercise6.p_2_32.entity;

public enum EAnimal {
    FISH,
    BEAR
}
