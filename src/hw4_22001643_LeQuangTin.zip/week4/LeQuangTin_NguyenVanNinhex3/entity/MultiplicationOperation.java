package week4.LeQuangTin_NguyenVanNinhex3.entity;

class MultiplicationOperation extends Operation {
    @Override
    public double perform(double number1, double number2) {
        return number1 * number2;
    }
}
