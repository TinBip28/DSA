package week4.LeQuangTin_NguyenVanNinhex3.entity;

public abstract class Operation {
    public abstract double perform(double number1, double number2);
}

