package week4.LeQuangTin_NguyenVanNinhex3;

import week4.LeQuangTin_NguyenVanNinhex3.controllers.SettingPanel;

public class AppTest {
    public static void main(String[] args) {
        SettingPanel setting = new SettingPanel();
        setting.showWindowns();
    }
}
