package week4.ex4;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedQueue<E> implements QueueInterface<E> {
    class LinkListQueue{

    }
    @Override
    public void enqueue(E element) {

    }

    @Override
    public E dequeue() {
        return null;
    }

    @Override
    public boolean isEmpty() {
        return false;
    }

    @Override
    public Iterator<E> iterator() {
        return null;
    }
}
