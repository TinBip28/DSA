package week5.practice3;

import week5.ex1.LinkedBinaryTree;

import java.io.FileWriter;
import java.io.IOException;

public class LinkedListBinaryTreeTest {
    public static void main(String[] args) {
        week5.ex1.LinkedBinaryTree<Integer, week5.ex1.LinkedBinaryTree.Node<Integer>> tree = new week5.ex1.LinkedBinaryTree<>();
        tree.addRoot(1);
        week5.ex1.LinkedBinaryTree.Node<Integer> nodeLeft = tree.addLeft(tree.root(), 2);
        week5.ex1.LinkedBinaryTree.Node<Integer> nodeRight = tree.addRight(tree.root(), 3);
        week5.ex1.LinkedBinaryTree.Node<Integer> leaf1 = tree.addLeft(nodeLeft, 4);
        week5.ex1.LinkedBinaryTree.Node<Integer> leaf2 = tree.addRight(nodeLeft, 6);
        week5.ex1.LinkedBinaryTree.Node<Integer> leaf3 = tree.addLeft(nodeRight, 5);
        LinkedBinaryTree.Node<Integer> leaf4 = tree.addRight(nodeRight, 7);
        tree.printTree(tree.root(), 0);
        System.out.println("\n");
        try {
            FileWriter fileWriter = new FileWriter("D:\\Intellij\\DSA\\src\\week5\\ex1\\outputLinked.txt");
            fileWriter.write("Linked Binary Tree\n");
            tree.writeTree(tree.root(),0,fileWriter);
            fileWriter.write("\n");
            fileWriter.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

}
