package week7.ex1;

public interface ListInterface<T> {
    public void add(T data);

    public void isContain(T data);

    public int size();

    public boolean isEmpty();


}
